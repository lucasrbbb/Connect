#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Exercicio 29\n");

    float valor;

    printf("Digite o valor da compra:");
    scanf("%f",&valor);

    printf("Novo preco de %.2f reais", valor*0.9);
}
