#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Exercicio 37\n");

    int tabuada;

    printf("Digite o numero da tabuada desejada: ");
    scanf("%d", &tabuada);

    printf("Tabuado\n");
    printf("%d x 1 = %d\n", tabuada, tabuada*1);
    printf("%d x 2 = %d\n", tabuada, tabuada*2);
    printf("%d x 3 = %d\n", tabuada, tabuada*3);
    printf("%d x 4 = %d\n", tabuada, tabuada*4);
    printf("%d x 5 = %d\n", tabuada, tabuada*5);
    printf("%d x 6 = %d\n", tabuada, tabuada*6);
    printf("%d x 7 = %d\n", tabuada, tabuada*7);
    printf("%d x 8 = %d\n", tabuada, tabuada*8);
    printf("%d x 9 = %d\n", tabuada, tabuada*9);
    printf("%d x 10 = %d\n", tabuada, tabuada*10);
}
