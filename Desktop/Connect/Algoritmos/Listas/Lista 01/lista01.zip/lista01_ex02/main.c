#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Exercicio 2\n");

    int n_cavalos;

    printf("Digite o numero de cavalos do aras:\n");
    scanf("%d", &n_cavalos);

    printf("O numero de ferraduras necessaria eh:\n%d unds.",4*n_cavalos);
}
