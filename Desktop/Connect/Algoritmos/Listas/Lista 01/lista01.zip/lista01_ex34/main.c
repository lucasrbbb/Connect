#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Exercicio 34\n");

    float lado;

    printf("Area quadrado\n");

    printf("Digite o tamanho do lado: ");
    scanf("%f", &lado);

    printf("Area quadrado: %.2f .\n", lado*lado);
}
