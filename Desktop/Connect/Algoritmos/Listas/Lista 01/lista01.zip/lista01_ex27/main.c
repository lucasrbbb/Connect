#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Exercicio 27\n");

    float n1, n2;

    printf("Digite o primeiro numero:");
    scanf("%f",&n1);

    printf("Digite o segundo numero:");
    scanf("%f",&n2);

    printf("A divisao de %.2f / %.2f = %.2f", n1, n2, n1/n2);
}
