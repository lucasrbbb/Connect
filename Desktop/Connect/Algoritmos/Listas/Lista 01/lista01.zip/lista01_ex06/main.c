#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Exercicio 6\n");

    float peso;

    printf("Insira o peso em kg:\n");
    scanf("%f", &peso);

    printf("O preco do prato eh %.2f reais.",peso*12);
}
